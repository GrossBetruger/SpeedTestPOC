package speed.testing.isp;

/**
 * Created by Dan on 12/10/2016.
 */
public enum ISP implements SpeedTestWebsite {

    HOT {
        @Override
        public String startTestButton() {
            return "isp\\startTestButtonHot.jpg";
        }

        @Override
        public String webUrl() {
            return "http://www.hot.net.il/heb/Internet/speed/";
        }

        @Override
        public int waitForTestToFinish() {
            return 30_000;
        }

        @Override
        public ISP ISP() {
            return this;
        }

    }, BEZEQ {
        @Override
        public String startTestButton() {
            return null;
        }

        @Override
        public String webUrl() {
            return null;
        }

        @Override
        public int waitForTestToFinish() {
            return 0;
        }

        @Override
        public ISP ISP() {
            return null;
        }

    }, OOKLA {
        @Override
        public String startTestButton() {
            return null;
        }

        @Override
        public String webUrl() {
            return null;
        }

        @Override
        public int waitForTestToFinish() {
            return 0;
        }

        @Override
        public ISP ISP() {
            return null;
        }
    }
}
