package speed.testing.isp;

/**
 * Created by Dan on 12/10/2016.
 */
public interface SpeedTestWebsite {

    String startTestButton();
    String webUrl();
    int waitForTestToFinish();
    ISP ISP();
}
