package speed.testing.utilites;


import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.channels.ReadableByteChannel;
import java.nio.file.Paths;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Stream;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Created by Dan on 08/10/2016.
 */
class FileUtils {

    // Logger
    private static Logger log = Logger.getLogger(FileUtils.class.getName());

    // Static Function

    // The method returns length, in bytes, of the file denoted by this abstract pathname.
    protected static double getFileSizeInBytes(String filePath) {
        return new File(filePath).length();
    }

    protected static double getFileSizeInMB(String filePath) {
        return getFileSizeInMB( getFileSizeInBytes(filePath) );
    }

    protected static double getFileSizeInMB(double fileSizeInBytes) {
        return fileSizeInBytes / Math.pow(2, 20); // Transform to MB
    }

    protected static String getFileNameFromURL(String url) {

        try {
            String[] tokens = url.split("/");
            return tokens[tokens.length - 1];

        } catch (Exception e) {
            return null;
        }
    }

    protected static void cleanBuffers(FileOutputStream fos, ReadableByteChannel rbc) {
        cleanFileOutputStream(fos);
        cleanReadableByteChannel(rbc);
    }

    protected static void cleanFileOutputStream(FileOutputStream fos) {

        try {
            if (fos != null) {
                fos.close();
            }

        } catch (IOException e) {
            log.warning(e.getMessage());
        }
    }

    protected static void cleanReadableByteChannel(ReadableByteChannel rbc) {

        try {
            if (rbc != null) {
                rbc.close();
            }

        } catch (IOException e) {
            log.warning(e.getMessage());
        }
    }

    protected static void deleteFile(String filePath) {
        deleteFile(new File(filePath));
    }

    protected static void deleteFile(File file) {

        try {
            if (file.exists()) {

                if (file.delete()) {
                    log.log(Level.INFO, file.getName() + " is deleted");
                } else {
                    log.warning("Error deleting " + file.getName() + " Delete operation is failed.");
                }
            }

        } catch (Exception e) {
            log.warning(e.getMessage());
        }
    }

    public static File getSubImageFile(String screenshot) throws IOException {

        if (screenshot == null) {
            return null;
        }

        File screenshotFile = new File(screenshot);
        File subImageFile = new File("subImage.jpg");
        BufferedImage fullImg = ImageIO.read(screenshotFile);

        BufferedImage downloadRateScreenshot = fullImg.getSubimage(345, 410, 60, 35);
        ImageIO.write(downloadRateScreenshot, "jpg", subImageFile);

        return subImageFile;
    }

    public static List<String> readFileByLines(String path) throws IOException {

        List<String> lines = new ArrayList<>();

        //read file into stream, try-with-resources
        try (Stream<String> stream = Files.lines(Paths.get(path))) {

            stream.forEach(lines::add);

        } catch (IOException e) {
            log.warning("Error: failed to read urls" + e.getMessage());
        }

        return lines;
    }
}
