package speed.testing.test;

import speed.testing.image.recognition.DriverBase;
import speed.testing.isp.SpeedTestWebsite;
import speed.testing.utilites.Utils;

import java.util.List;

/**
 * Created by Dan on 24/10/2016.
 */
public class Test {

    // Fields
    private String               testID;
    private SystemInfo           systemInfo;
    private SpeedTestWebsite     SpeedTestWebsite;
    private List<String>         urls;
    private List<ComparisonInfo> comparisonInfoTests;

    // Constructor
    public Test(SpeedTestWebsite SpeedTestWebsite, List<String> urls) {
        this.comparisonInfoTests = null;
        this.testID = Utils.generateUniqueID();
        this.urls = urls;
        this.SpeedTestWebsite = SpeedTestWebsite;
        this.systemInfo = new SystemInfo(DriverBase.getConnection());
    }

    // Methods

    public String getTestID() {
        return testID;
    }

    public void setTestID(String testID) {
        this.testID = testID;
    }

    public SpeedTestWebsite getSpeedTestWebsite() {
        return SpeedTestWebsite;
    }

    public void setSpeedTestWebsite(SpeedTestWebsite speedTestWebsite) {
        this.SpeedTestWebsite = speedTestWebsite;
    }

    public List<String> getUrls() {
        return urls;
    }

    public void setUrls(List<String> urls) {
        this.urls = urls;
    }

    public SystemInfo getSystemInfo() {
        return systemInfo;
    }

    public void setSystemInfo(SystemInfo systemInfo) {
        this.systemInfo = systemInfo;
    }

    public List<ComparisonInfo> getComparisonInfoTests() {
        return comparisonInfoTests;
    }

    public void setComparisonInfoTests(List<ComparisonInfo> speedTests) {
        this.comparisonInfoTests = speedTests;
    }
}
