package speed.testing.test;

/**
 * Created by Dan on 12/10/2016.
 */
public class ComparisonInfo {

    // Fields
    private String           testID;
    private ISPDownloadInfo  ispDownloadInfo;
    private FileDownloadInfo fileDownloadInfo;

    // Constructor
    public ComparisonInfo(String ID, ISPDownloadInfo ispDownloadInfo, FileDownloadInfo fileDownloadInfo) {
        this.testID = ID;
        this.ispDownloadInfo = ispDownloadInfo;
        this.fileDownloadInfo = fileDownloadInfo;
    }

    // Methods
    public String getTestID() {
        return testID;
    }

    public ISPDownloadInfo getIspDownloadInfo() {
        return ispDownloadInfo;
    }

    public FileDownloadInfo getFileDownloadInfo() {
        return fileDownloadInfo;
    }

}
