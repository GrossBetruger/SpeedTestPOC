package speed.testing.test;

import speed.testing.data.access.DataAccessInteractor;
import speed.testing.image.recognition.WebManager;
import speed.testing.isp.SpeedTestWebsite;
import speed.testing.image.recognition.WebManagerEngine;
import speed.testing.utilites.Utils;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLDecoder;
import java.nio.channels.Channels;
import java.nio.channels.ReadableByteChannel;
import java.util.*;
import java.util.logging.Logger;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

/**
 * Created by Dan on 12/10/2016.
 */
public class  TestManager {

    // Logger
    private Logger log = Logger.getLogger(WebManagerEngine.class.getName());

    // Fields
    private final int MAX_ATTEMPTS_RETRIEVE_DOWNLOAD_IMG = 5;
    private WebManager webManager;
    private DataAccessInteractor dataAccessInteractor;

    // Constructor
    public TestManager(DataAccessInteractor dataAccessInteractor) {
        this.dataAccessInteractor = dataAccessInteractor;
    }

    // Methods

    public void executeTest(Test test) {

        List<ComparisonInfo> tests = null;

        try {
            tests = test.getUrls()
                        .stream()
                        .map(url -> startNewTest(test.getTestID(), test.getSpeedTestWebsite(), url))
                        .filter(this::validateComparisonInfo)
                        .collect(Collectors.toList());


            log.info("Done test");
        } catch (Exception e) {
            log.warning("Error: Failed to execute test " + e.getMessage());
        }

        test.setComparisonInfoTests(tests);
        dataAccessInteractor.saveTest(test);
        ReportGenerator.GENERATOR.printSpeedTestResult(test);
    }

    private boolean validateComparisonInfo(ComparisonInfo comparisonInfo) {
        return comparisonInfo != null &&
               comparisonInfo.getFileDownloadInfo() != null &&
               comparisonInfo.getIspDownloadInfo() != null;
    }

    public void injectWebManager(WebManager webManager) {
        this.webManager = webManager;
    }

    private ComparisonInfo startNewTest(String testID, SpeedTestWebsite SpeedTestWebsite, String url) {

        ISPDownloadInfo ispDownloadInfo = getDownloadRateFromISPSpeedTest(testID, SpeedTestWebsite);
        FileDownloadInfo fileDownloadInfo = generateFileDownloadInfo(testID, url);
        ComparisonInfo comparisonInfo = new ComparisonInfo(testID, ispDownloadInfo, fileDownloadInfo);

        return comparisonInfo;
    }

    private ISPDownloadInfo getDownloadRateFromISPSpeedTest(String testID, SpeedTestWebsite SpeedTestWebsite) {

        try {

            return IntStream.iterate(0, attemptsToGetDownloadRate -> ++attemptsToGetDownloadRate)
                    .limit(MAX_ATTEMPTS_RETRIEVE_DOWNLOAD_IMG)
                    .mapToObj(attemptsToGetDownloadRate -> generateISPDownloadInfo(testID, SpeedTestWebsite))
                    .filter(Objects::nonNull)
                    .findFirst()
                    .orElse(null);

        } catch (Exception e) {
            return null;
        }
    }

    private ISPDownloadInfo generateISPDownloadInfo(String testID, SpeedTestWebsite speedTestWebsite) {
        return webManager.generateISPDownloadInfo(testID, speedTestWebsite);
    }

    private FileDownloadInfo generateFileDownloadInfo(String testID, String url) {

        double fileSizeInBytes;
        long totalDownloadingTimeInMs;
        URL webSite;
        FileOutputStream fos;
        ReadableByteChannel rbc;
        Date startDownloadingTime;
        HttpURLConnection con;

        String fileName = Utils.getFileNameFromURL(url);
        String tempFileName = "tempFile_" + testID;

        try {
            // preparation for file downloading
            webSite = new URL(url);
            fos = new FileOutputStream(tempFileName);

            con = setUpConnection(webSite);
            rbc = Channels.newChannel(con.getInputStream());

            startDownloadingTime = new Date();
            totalDownloadingTimeInMs = getDownloadRateFromISPSpeedTest(testID, fos, rbc, fileName); // download file

            fileSizeInBytes = Utils.getFileSizeInBytes(tempFileName);

            Utils.cleanBuffers(fos, rbc);
            Utils.deleteFile(tempFileName);

            return generateFileDownloadInfo(url, totalDownloadingTimeInMs, fileSizeInBytes, fileName, startDownloadingTime);

        } catch (Exception e) {
            log.warning(e.getMessage());
            return null;
        }
    }

    private HttpURLConnection setUpConnection(URL webSite) throws IOException {

        HttpURLConnection con = (HttpURLConnection)(webSite.openConnection());
        System.setProperty("http.agent","");
        con.setRequestProperty("User-Agent","Mozilla/5.0 (Windows NT 6.1; WOW64) " +
                                            "AppleWebKit/534.30 (KHTML, like Gecko) " +
                                            "Chrome/12.0.742.100 Safari/534.30");
        return con;
    }

    private long getDownloadRateFromISPSpeedTest(String testID, FileOutputStream fos, ReadableByteChannel rbc, String fileName) {

        long startDownloadingTime;
        long endDownloadingTime;

        try {
            // Download file and measure total download time
            log.info("Speed-Test " + testID + "; start downloading " + fileName + " at " + Utils.formatter.format(new Date()));
            startDownloadingTime = System.currentTimeMillis();
            fos.getChannel().transferFrom(rbc, 0, Long.MAX_VALUE);
            endDownloadingTime = System.currentTimeMillis();

        } catch (Exception e) {
            log.warning("Failed to download file " + e.getMessage());
            throw new RuntimeException("Failed to download file " + e.getMessage());
        }

        return (endDownloadingTime - startDownloadingTime);
    }

    private FileDownloadInfo generateFileDownloadInfo(String url, long totalDownloadingTimeInMs,
                                                      double fileSizeInBytes, String fileName,
                                                      Date startDownloadingTime) throws UnsupportedEncodingException {

        FileDownloadInfo fileDownloadInfo = new FileDownloadInfo(url);
        fileDownloadInfo.setFileName(URLDecoder.decode(fileName, "UTF-8"));
        fileDownloadInfo.setFileSizeInBytes(fileSizeInBytes);
        fileDownloadInfo.setFileDownloadedTimeInMs(totalDownloadingTimeInMs);
        fileDownloadInfo.setStartDownloadingTime(startDownloadingTime);
        fileDownloadInfo.setFileDownloadRateKBPerSec(Utils.round(fileDownloadInfo.downloadRateKBperSec(), 2));

        return fileDownloadInfo;
    }
}
