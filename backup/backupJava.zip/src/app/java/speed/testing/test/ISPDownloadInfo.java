package speed.testing.test;

import javafx.util.Pair;
import speed.testing.data.access.Query;
import speed.testing.isp.ISP;
import speed.testing.utilites.Utils;

import java.sql.Types;
import java.util.Date;
import java.util.LinkedList;

/**
 * Created by Dan on 12/10/2016.
 */
public class ISPDownloadInfo{

    private ISP isp;
    private double downloadSpeedRateMb;
    private Date startMeasuringTime;

    public ISPDownloadInfo(ISP isp, double downloadSpeedRate, Date startDownloadingTime) {
        this.isp = isp;
        this.downloadSpeedRateMb = downloadSpeedRate;
        this.startMeasuringTime = startDownloadingTime;
    }

    public ISP getIsp() {
        return isp;
    }

    public double getDownloadSpeedRateMb() {
        return downloadSpeedRateMb;
    }
    public Date getStartMeasuringTime() {
        return startMeasuringTime;
    }

    public double getDownloadRateInKB() {
        return (downloadSpeedRateMb /8.0) * Math.pow(2,10);
    }

    @Override
    public String toString() {
        return "ISPDownloadInfo{" +
                "isp=" + isp +
                ", downloadSpeedRateMb=" + downloadSpeedRateMb +
                ", startMeasuringTime=" + Utils.formatter.format(startMeasuringTime) +
                '}';
    }
}
