package speed.testing;

import speed.testing.data.access.*;
import speed.testing.image.recognition.*;
import speed.testing.isp.ISP;
import speed.testing.test.Test;
import speed.testing.test.TestManager;
import speed.testing.utilites.Utils;

import java.io.IOException;
import java.util.*;
import java.util.logging.Logger;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

/**
 * Created by Dan on 08/10/2016.
 */
public class App {

    static {
        try {
            DriverBase.getDriver();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // Static Fields
    private final static Logger log = Logger.getLogger(App.class.getName());

    // Final fields
    private final String urlPath = "url.txt";

    // Fields
    private WebManagerEngine      webManager;
    private TestManager           testManager;
    private DataAccessInteractor  dto;
    private List<Cleanable>       cleanableList;
    private List<String>          urls;

    private App() throws IOException {

        cleanableList = new ArrayList<>();
        urls          = readUrlsFromFile();
        dto           = new RDBSManager(DataBase.POSTGRESQL);
        testManager   = new TestManager(dto);

        setUpWebManager();
    }

    private void setUpWebManager() {

        WebElementRecognition webElementRecognition = new SikuliEngine();
        OcrEngine ocrEngine = new AsproseOcrEngine();
        webManager = new WebManagerEngine(webElementRecognition, ocrEngine);

        webManager.setButtonImagePath("NoButton.PNG");
        ocrEngine.injectCloseableUiElement(webManager);
        testManager.injectWebManager(webManager);

        cleanableList.add(ocrEngine);
    }

    private List<String> readUrlsFromFile() throws IOException {
        List<String> urlsFromFile = Utils.readFileByLines(urlPath);

        return urlsFromFile.stream()
                           .filter(url -> !url.startsWith("//"))
                           .collect(Collectors.toList());
    }

    private void runTest(int intervals) {

        IntStream.iterate(0, i -> ++i)
                 .limit(intervals)
                 .mapToObj(i -> new Test(ISP.HOT, urls))
                 .forEach(testManager::executeTest);
    }

    private void closeApp() {
        cleanableList.forEach(Cleanable::clean);
    }

    public static void main(String[] args) {

        App app;

        try {
            app = new App();
        } catch (IOException e) {
            log.warning("Error: Failed to initialized Application");
            return;
        }

        app.runTest(1);
        app.closeApp();
    }
}
