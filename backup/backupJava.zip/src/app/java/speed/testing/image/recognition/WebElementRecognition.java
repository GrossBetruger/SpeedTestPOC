package speed.testing.image.recognition;

/**
 * Created by Dan on 12/10/2016.
 */
public interface WebElementRecognition {

   /*
    *   Click on element on the screen by the given image
    *   The method search for the image on the screen and click on it
    *   return false if image not recognized or not selected
    */
    boolean clickImage(String imagePath);

   /*
    *   Take snapshot of web screen
    *   @return the path of taking screenshot
    */
    String takeScreenPic();
}
