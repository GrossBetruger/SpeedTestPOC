package speed.testing.image.recognition;

import com.asprise.ocr.Ocr;
import com.google.common.cache.Cache;
import speed.testing.App;
import speed.testing.Cleanable;

import java.awt.*;
import java.io.File;
import java.util.Objects;
import java.util.concurrent.*;
import java.util.logging.Logger;
import java.util.stream.IntStream;

/**
 * Created by Dan on 04/10/2016.
 */
public class AsproseOcrEngine implements OcrEngine {

    // Logger
    private Logger log = Logger.getLogger(AsproseOcrEngine.class.getName());

    // Final Fields
    private final int MAX_ATTEMPTS_CONVERT_IMAGE = 10;

    // Fields
    private int countPageRecognized;
    private Ocr ocr;
    private CloseUIElement closeUIElement = null;
    private ExecutorService executor;

    // Constructor
    public AsproseOcrEngine() {

        countPageRecognized = 0;
        executor = Executors.newSingleThreadExecutor();
        initOcrEngine();
    }

    //Methods

    private void initOcrEngine() {
        ocr = new Ocr(); // create a new OCR engine
        ocr.startEngine("eng", Ocr.SPEED_FASTEST); // English
    }

    @Override
    public void injectCloseableUiElement(CloseUIElement closeUIElement) {
        this.closeUIElement = closeUIElement;
    }

    @Override
    public String convertImageFileToString(File imageFile) {

        String convertedStr =

        IntStream.iterate(0, index  -> ++index)
                 .limit(MAX_ATTEMPTS_CONVERT_IMAGE)
                 .mapToObj(index -> convertImage(imageFile))
                 .filter(Objects::nonNull)
                 .findFirst()
                 .orElse(null);

        return convertedStr;
    }

    private String convertImage(File imageFile) {

        String convertedStr = null;
        Future<String> ref;

        try {
            ref = executor.submit(new RecognizeImage(imageFile));
            convertedStr = ref.get(2500, TimeUnit.MILLISECONDS);

        } catch (InterruptedException e) {
            log.warning(e.getMessage());
        } catch (ExecutionException e) {
            log.warning(e.getMessage());
        } catch (TimeoutException e) {

            log.info("Pop up window opened, trying to close it");
            closeUIElement.closeElement();

        } catch (Exception e) {
            log.warning(e.getMessage());
        }

        countPageRecognized++;

        // After recognized 90 pages the OCR engine need to restart
        if (countPageRecognized >= 90) {
            log.info("Reached max converted pages, restart AsporeOcrEngine");
            restartEngine();
        }

        return convertedStr;
    }

    private void restartEngine() {
        clean();
        initOcrEngine();
        countPageRecognized = 0;
    }

    @Override
    public void clean() {
        ocr.stopEngine();
    }

    /**
     *  @author Dan.
     */
    private class RecognizeImage implements Callable<String> {

        private File imageFile;

        public RecognizeImage(File imageFile) {
            this.imageFile = imageFile;
        }

        @Override
        public String call() throws Exception {
            Thread.currentThread().setName("OCR Thread");
            return ocr.recognize(new File[]{imageFile}, Ocr.RECOGNIZE_TYPE_ALL, Ocr.OUTPUT_FORMAT_PLAINTEXT);
        }
    }
}
