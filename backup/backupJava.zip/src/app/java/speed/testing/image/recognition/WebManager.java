package speed.testing.image.recognition;

import speed.testing.isp.SpeedTestWebsite;
import speed.testing.test.ISPDownloadInfo;

/**
 * Created by Dan on 24/10/2016.
 */
public interface WebManager {
    ISPDownloadInfo generateISPDownloadInfo(String testID, SpeedTestWebsite speedTestWebsite);
}
