package speed.testing.data.access;

import speed.testing.test.ComparisonInfo;
import speed.testing.test.Test;
import speed.testing.utilites.DBUtil;

import java.util.List;

/**
 * Created by Dan on 23/10/2016.
 */
public class RDBSManager implements DataAccessInteractor {

    // Fields
    private DBType dbType;

    // Constructor
    public RDBSManager(DBType dbType) {
        this.dbType = dbType;
    }

    // Methods

    @Override
    public void saveTest(Test test) {
        DBUtil.insertSpeedTestRecord(dbType, test);
    }

    @Override
    public List<ComparisonInfo> getAllTests() {
        return null;
    }
}
