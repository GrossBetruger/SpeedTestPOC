package speed.testing.data.access;

import speed.testing.utilites.Utils;

/**
 * Created by Dan on 28/10/2016.
 */
public class JSONDownloadComparison {

    // Fields
    private transient String name;
    private String url;
    private String file_name;
    private String file_download_start_time;
    private String speed_test_start_time;
    private double file_size_bytes;
    private double file_download_rate_KBs;
    private double speed_test_result_mbs;

    // Constructor
    public JSONDownloadComparison() {}

    // Methods

    public String getName() {
        return name;
    }

    public void setName(String url) {
        this.name = Utils.generateNameFromFileName(url);
    }

    public double getFile_size_bytes() {
        return file_size_bytes;
    }

    public void setFile_size_bytes(double file_size_bytes) {
        this.file_size_bytes = file_size_bytes;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getFile_name() {
        return file_name;
    }

    public void setFile_name(String file_name) {
        this.file_name = file_name;
    }

    public String getFile_download_start_time() {
        return file_download_start_time;
    }

    public void setFile_download_start_time(String file_download_start_time) {
        this.file_download_start_time = file_download_start_time;
    }

    public double getFile_download_rate_KBs() {
        return file_download_rate_KBs;
    }

    public void setFile_download_rate_KBs(double file_download_rate_KBs) {
        this.file_download_rate_KBs = file_download_rate_KBs;
    }

    public String getSpeed_test_start_time() {
        return speed_test_start_time;
    }

    public void setSpeed_test_start_time(String speed_test_start_time) {
        this.speed_test_start_time = speed_test_start_time;
    }

    public double getSpeed_test_result_mbs() {
        return speed_test_result_mbs;
    }

    public void setSpeed_test_result_mbs(double speed_test_result_mbs) {
        this.speed_test_result_mbs = speed_test_result_mbs;
    }

}
