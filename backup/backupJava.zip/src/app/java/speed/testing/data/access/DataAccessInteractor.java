package speed.testing.data.access;

import speed.testing.test.ComparisonInfo;
import speed.testing.test.Test;

import java.util.List;

/**
 * Created by Dan on 22/10/2016.
 */
public interface DataAccessInteractor {
    void saveTest(Test test);
    List<ComparisonInfo> getAllTests();
}
