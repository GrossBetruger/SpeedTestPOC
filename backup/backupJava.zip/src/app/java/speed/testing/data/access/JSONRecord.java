package speed.testing.data.access;

import com.google.gson.Gson;
import speed.testing.test.ComparisonInfo;
import speed.testing.test.Test;
import speed.testing.utilites.Utils;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * Created by Dan on 28/10/2016.
 */
public class JSONRecord {

    // Fields
    private String test_id;
    private String operating_system;
    private String public_ip;
    private String connection;
    private String speed_test_website;
    private String browser;
    private Object comparison_info;

    // Constructor
    public JSONRecord(Test test) {
        this.test_id = test.getTestID();
        this.operating_system = test.getSystemInfo().getOperatingSystem();
        this.public_ip = test.getSystemInfo().getPublicIP();
        this.connection = test.getSystemInfo().getConnection();
        this.speed_test_website = test.getSpeedTestWebsite().ISP().name();
        this.browser = test.getSystemInfo().getBrowser();
        this.comparison_info = generateJsonDownloadComparison(test.getComparisonInfoTests());
    }

    private Map<String, Object> generateJsonDownloadComparison(List<ComparisonInfo> comparisonInfoTests) {

        return comparisonInfoTests.stream()
                                  .map(this::generateJsonDownloadComparison)
                                  .collect(Collectors.toMap(info -> info.getName(), info -> info));
    }

    private JSONDownloadComparison generateJsonDownloadComparison(ComparisonInfo comparisonInfo) {

        JSONDownloadComparison jsonDownloadComparison = new JSONDownloadComparison();

        jsonDownloadComparison.setName(comparisonInfo.getFileDownloadInfo().getFileURL());
        jsonDownloadComparison.setUrl(comparisonInfo.getFileDownloadInfo().getFileURL());
        jsonDownloadComparison.setFile_name(comparisonInfo.getFileDownloadInfo().getFileName());
        jsonDownloadComparison.setFile_download_start_time(Utils.formatter.format(comparisonInfo.getFileDownloadInfo().getStartDownloadingTime()));
        jsonDownloadComparison.setSpeed_test_start_time(Utils.formatter.format(comparisonInfo.getIspDownloadInfo().getStartMeasuringTime()));
        jsonDownloadComparison.setFile_size_bytes(comparisonInfo.getFileDownloadInfo().getFileSizeInBytes());
        jsonDownloadComparison.setFile_download_rate_KBs(comparisonInfo.getFileDownloadInfo().getFileDownloadRateKBPerSec());
        jsonDownloadComparison.setSpeed_test_result_mbs(comparisonInfo.getIspDownloadInfo().getDownloadSpeedRateMb());

        return jsonDownloadComparison;
    }

    // Methods

    public String getInsertString() {
        return Query.INSERT_JSON_RECORD;
    }

    public String toJsonString() {
        Gson gson = new Gson();
        return gson.toJson(this);
    }

    public String getTest_id() {
        return test_id;
    }

    public String getOperating_system() {
        return operating_system;
    }

    public String getPublic_ip() {
        return public_ip;
    }

    public String getConnection() {
        return connection;
    }

    public String getSpeed_test_website() {
        return speed_test_website;
    }

    public String getBrowser() {
        return browser;
    }

    public Object getComparison_info() {
        return comparison_info;
    }

    @Override
    public String toString() {
        return super.toString();
    }
}
