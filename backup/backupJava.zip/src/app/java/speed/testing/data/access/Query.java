package speed.testing.data.access;


/**
 * Created by Dan on 22/10/2016.
 */
public class Query {

    private static final String GET_ALL_RECORDS = "Select * from %s";

    public static final String INSERT_SYSTEM_INFO = "INSERT INTO system_info " +
            "(test_id, operating_system, browser, public_IP, connection) " +
            " VALUES (?, ?, ?, ?, ?)";

    public static final String INSERT_ISP_SPEED_TEST = "INSERT INTO ISP_speed_test_website_download_info " +
            "(test_id, name, download_speed_rate_mbs, start_measuring_time) " +
            " VALUES (?, ?, ?, ?)";

    public static final String INSERT_FILE_DOWNLOAD_INFO = "INSERT INTO file_download_info " +
            "(test_id, file_url, file_name, file_size_in_bytes, file_downloaded_time_in_ms, file_download_rate_KBs, startDownloadingTime) " +
            " VALUES (?, ?, ?, ?, ?, ?, ?)";

    public static final String INSERT_JSON_RECORD = "INSERT INTO internet_speed_test_data " +
            "(data) " +
            " VALUES (?)";


    public static String getGetAllRecords(String table) {
        return String.format(GET_ALL_RECORDS, table);
    }
}
