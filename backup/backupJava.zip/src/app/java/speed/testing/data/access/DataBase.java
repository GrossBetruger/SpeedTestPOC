package speed.testing.data.access;

/**
 * Created by Dan on 22/10/2016.
 */
public enum DataBase implements DBType {

    MY_SQL_LOCAL {

        @Override
        public String connectionString() {
            return "jdbc:mysql://127.0.0.1:3306/?user=root";
        }

        @Override
        public String dataBaseName() {
            return "test_db";
        }

        @Override
        public String getName() {
            return this.name();
        }

        @Override
        public String getUserName() {
            return "DangOren";
        }

        @Override
        public String getPassword() {
            return "lsdMdma22";
        }
    },

    POSTGRESQL {
        @Override
        public String connectionString() {
            return "jdbc:postgresql://speedtestproduction.c6bjskxymj4x.us-west-2.rds.amazonaws.com:5432/speedtestProduction";
        }

        @Override
        public String dataBaseName() {
            return "speedtestProduction";
        }

        @Override
        public String getName() {
            return "PostgreSQL";
        }

        @Override
        public String getUserName() {
            return "DangOren";
        }

        @Override
        public String getPassword() {
            return "androhanwillanswer";
        }
    }
}
