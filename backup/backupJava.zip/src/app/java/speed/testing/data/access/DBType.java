package speed.testing.data.access;

/**
 * Created by Dan on 22/10/2016.
 */
public interface DBType {

    String connectionString();
    String dataBaseName();
    String getName();
    String getUserName();
    String getPassword();
}
