package speed.testing;

/**
 * Created by Dan on 15/10/2016.
 */
public interface Cleanable {
    void clean();
}
