package speed.testing.utilites;

import org.postgresql.util.PGobject;
import speed.testing.data.access.DBType;
import speed.testing.data.access.JSONRecord;
import speed.testing.test.Test;

import java.sql.*;
import java.util.logging.Logger;

/**
 * Created by Dan on 22/10/2016.
 */
public class DBUtil {

    // Logger
    private static Logger log = Logger.getLogger(DBUtil.class.getName());

    // Static Functions

    public static void insertSpeedTestRecord(DBType dbType, Test test) {

        if (test == null) { return; }

        JSONRecord record = new JSONRecord(test);

        if (record != null && Validator.validateJSONRecord(record)) {
            insertJsonRecord(dbType, record);
        }
    }

    private static void insertJsonRecord(DBType dbType, JSONRecord jsonRecord) {

        try (Connection conn = getConnection(dbType);
             PreparedStatement stmt = getPreparedStatementInsertSQLRecord(conn, jsonRecord.getInsertString(), jsonRecord)) {

            int affected = stmt.executeUpdate();

            if (affected == 1) {
                log.info(jsonRecord.toString() + " saved at: " + dbType.getName());
                System.out.println(jsonRecord.toString() + " saved at: " + dbType.getName());
            } else {
                log.warning("Failed to insert record " + jsonRecord.toString() + " to DB: " + dbType.dataBaseName());
                System.out.println("Failed to insert record " + jsonRecord.toString() + " to DB: " + dbType.dataBaseName());
            }
        } catch (SQLException e) {
            DBUtil.processSqlException(e);
        }
    }

    public static Connection getConnection(DBType type) throws SQLException {
        return getConnection(type, type.getUserName(), type.getPassword());
    }

    private static Connection getConnection(DBType type, String user, String password) throws SQLException {
        return DriverManager.getConnection(type.connectionString() , user, password);
    }

    private static PreparedStatement getPreparedStatementInsertSQLRecord(Connection conn, String insertQuery, JSONRecord jsonRecord) throws SQLException {

        PreparedStatement stmt = conn.prepareStatement(insertQuery, Statement.RETURN_GENERATED_KEYS);
        PGobject jsonObject = new PGobject();

        jsonObject.setType("json");
        jsonObject.setValue(jsonRecord.toJsonString());

        stmt.setObject(1, jsonObject);

        return stmt;
    }

    private static void processSqlException(SQLException e) {
        log.warning("Error message: " + e.getMessage());
        log.warning("Error code: " + e.getErrorCode());
        log.warning("SQL state: " + e.getSQLState());
    }
}
