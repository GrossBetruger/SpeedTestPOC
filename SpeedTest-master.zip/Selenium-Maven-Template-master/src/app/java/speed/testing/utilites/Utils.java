package speed.testing.utilites;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.channels.ReadableByteChannel;
import java.text.SimpleDateFormat;
import java.util.List;
import java.util.UUID;
import java.util.logging.Logger;

/**
 * Created by Dan on 04/10/2016.
 */
public class Utils {

    // Logger
    private static Logger log = Logger.getLogger(Utils.class.getName());

    public final static SimpleDateFormat formatter = new SimpleDateFormat("YYYY-MM-dd HH:mm:ss");

    public static double convertStrToDouble(String downloadRateStr) {

        try {
            return Double.parseDouble(downloadRateStr);

        } catch (NumberFormatException e) {
            log.warning("Couldn't convert string: " + downloadRateStr +  " to double");
        }

        return -1;
    }

    public static double round(double value, int places) {

        if (places < 0) {
            throw new IllegalArgumentException();
        }

        long factor = (long) Math.pow(10, places);
        value = value * factor;
        long tmp = Math.round(value);

        return (double) tmp / factor;
    }

    public static String getFileSizeInMB(double fileSizeInBytes) {
        return Double.toString(round(FileUtils.getFileSizeInMB(fileSizeInBytes), 2));
    }

    public static List<String> readFileByLines(String path) throws IOException {
        return FileUtils.readFileByLines(path);
    }

    public static void deleteFile(File file) {
        FileUtils.deleteFile(file);
    }

    public static String getFileNameFromURL(String url) {
        return FileUtils.getFileNameFromURL(url);
    }

    public static double getFileSizeInBytes(String tempFileName) {
        return FileUtils.getFileSizeInBytes(tempFileName);
    }

    public static File getSubImageFile(String screenShot) throws IOException {
        return FileUtils.getSubImageFile(screenShot);
    }

    public static void cleanBuffers(FileOutputStream fos, ReadableByteChannel rbc) {
        FileUtils.cleanBuffers(fos, rbc);
    }

    public static void deleteFile(String tempFileName) {
        FileUtils.deleteFile(tempFileName);
    }

    public static String generateUniqueID() {
        return UUID.randomUUID().toString();
    }

    public static String generateNameFromFileName(String url) {

        String testName = "test_";

        if (url.contains("firefox")) {
            testName += "firefox";
        } else if (url.contains("kodi")) {
            testName += "kodi";
        } else if (url.contains("postgresql")) {
            testName += "postgresql";
        } else if (url.contains("aws-java-sdk")) {
            testName += "aws-java-sdk";
        } else if (url.contains("google")) {
            testName += "google-go";
        } else if (url.contains("KinectSDK")) {
            testName += "KinectSDK";
        } else if (url.contains("iTunes")) {
            testName += "iTunes";
        } else if (url.contains("skype")) {
            testName += "skype";
        } else {
            testName += "UNKNOWN";
        }

        return testName;
    }
}
