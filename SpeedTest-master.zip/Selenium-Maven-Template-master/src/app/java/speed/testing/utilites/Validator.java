package speed.testing.utilites;

import org.apache.commons.validator.UrlValidator;
import speed.testing.data.access.JSONDownloadComparison;
import speed.testing.data.access.JSONRecord;
import speed.testing.image.recognition.WebManagerEngine;
import speed.testing.image.recognition.config.DriverType;
import speed.testing.isp.ISP;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Map;
import java.util.logging.Logger;
import java.util.regex.Pattern;

/**
 * Created by Dan on 29/10/2016.
 */
public class Validator {

    // Logger
    private static Logger log = Logger.getLogger(Validator.class.getName());

    private static String[] schemes = {"http","https"};

    private static final Pattern IP_PATTERN = Pattern.compile(
            "^(([01]?\\d\\d?|2[0-4]\\d|25[0-5])\\.){3}([01]?\\d\\d?|2[0-4]\\d|25[0-5])$");


    public  static boolean validateJSONRecord(JSONRecord record) {
        return isValidateMetaData(record) && isValidateComparisonInfo(record.getComparison_info());
    }

    private static boolean isValidateComparisonInfo(Object comparison_info) {

        Map<String, JSONDownloadComparison> comparisonInfoMap;

        try {
            comparisonInfoMap = (Map<String, JSONDownloadComparison>)comparison_info;
            System.out.println(comparison_info);

            boolean ans = comparisonInfoMap.entrySet()
                             .stream()
                             .map((entry) -> isValidateJsonComparison(entry))
                             .filter( isValidateSuccessful -> !isValidateSuccessful)
                             .findFirst()
                             .orElse(true);

        } catch (Exception e) {
            return false;
        }

        return true;
    }

    private static boolean isValidateJsonComparison(Map.Entry<String, JSONDownloadComparison> entry) {
        try {
            return isValidateString(entry.getKey()) && isValidateJsonComparison(entry.getValue());
        } catch (Exception e) {
            return false;
        }
    }

    private static boolean isValidateJsonComparison(JSONDownloadComparison jsonComparison) {

        return isValidateString(jsonComparison.getName()) &&
               isValidateURL(jsonComparison.getUrl()) &&
               isValidateString(jsonComparison.getFile_name()) &&
               isValidDate(jsonComparison.getFile_download_start_time()) &&
               isValidDate(jsonComparison.getSpeed_test_start_time()) &&
               isValidDouble(jsonComparison.getFile_size_bytes()) &&
               isValidDouble(jsonComparison.getFile_download_rate_KBs()) &&
               isValidDouble(jsonComparison.getSpeed_test_result_mbs());
    }

    public static boolean isValidateURL(String url) {
        UrlValidator urlValidator = new UrlValidator(schemes);
        return isValidateString(url) && urlValidator.isValid(url);
    }

    public static boolean isValidDate(String inDate) {

        if (!isValidateString(inDate)) { return false; }

        SimpleDateFormat dateFormat = Utils.formatter;
        try {
            dateFormat.parse(inDate.trim());
        } catch (ParseException pe) {
            return false;
        }
        return true;
    }

    private static boolean isValidateMetaData(JSONRecord record) {

        return isValidateString(record.getTest_id()) &&
               isValidateString(record.getOperating_system()) &&
               isValidateIPAddress(record.getPublic_ip()) &&
               isValidateConnection(record.getConnection()) &&
               isValidateSpeedTestWebSite(record.getSpeed_test_website()) &&
               isValidateBrowser(record.getBrowser());
    }

    private static boolean isValidateIPAddress(String ip) {
        return  isValidateString(ip) && IP_PATTERN.matcher(ip).matches();
    }

    private static boolean isValidateConnection(String connection) {
        return isValidateString(connection) &&
               ( connection.equalsIgnoreCase("lan")  ||
                 connection.equalsIgnoreCase("wifi") ||
                 connection.equalsIgnoreCase("unknown") );
    }

    private static boolean isValidateSpeedTestWebSite(String ispWebSite) {

        if (!isValidateString(ispWebSite)) { return false; }

        for (ISP isp: ISP.values()) {
            if (isp.name().equals(ispWebSite)) {
                return true;
            }
        }

        return false;
    }

    private static boolean isValidateBrowser(String browser) {

        if (!isValidateString(browser)) { return false; }

        for (DriverType type : DriverType.values()) {
            if (type.name().equals(browser)) {
                return true;
            }
        }

        return false;
    }

    private static boolean isValidateString(String str) {
        return str != null && !str.isEmpty();
    }

    private static boolean isValidDouble(double num) {
        return num > 0;
    }
}
