package speed.testing.test;


import speed.testing.utilites.Utils;

/**
 * Created by Dan on 04/10/2016.
 */
public enum ReportGenerator {

    GENERATOR;

    public void printSpeedTestResult(Test test) {
        System.out.println(getTestPrint(test));
    }

    private String getTestPrint(Test test) {
        StringBuilder sb  = new StringBuilder();
        sb.append("*******************************\n");
        sb.append("Test ID : " + test.getTestID() + "\n");
        sb.append("Speed test web site : " + test.getSpeedTestWebsite() + "\n");
        sb.append("System info : " + test.getSystemInfo() + "\n");
        sb.append("*******************************\n");
        test.getComparisonInfoTests().forEach(info -> sb.append(ReportGenerator.GENERATOR.generateSpeedTestReport(info)));

        return sb.toString();
    }

    public void printComparisonInfoResult(ComparisonInfo comparisonInfo) {
        try {
            System.out.println(generateSpeedTestReport(comparisonInfo));
        } catch (Exception e) {
            System.out.println("Error while prinitng report");
        }
    }

    private String generateSpeedTestReport(ComparisonInfo comparisonInfo) {

        StringBuilder sb  = new StringBuilder();

        sb.append("*******************************\n");
        sb.append(getISPDownloadInfo(comparisonInfo.getIspDownloadInfo()) + "\n");
        sb.append("-----------------------\n");
        sb.append(getFileDownloadInfo(comparisonInfo.getFileDownloadInfo()) + "\n");
        sb.append("*******************************\n");

        return sb.toString();
    }

    public String getFileDownloadInfo(FileDownloadInfo info) {

        return "File Download Info:\n" +
                "   URL  : " + info.getFileURL() + "\n" +
                "   Name : '" + info.getFileName() + "'\n" +
                "   Size : " + Utils.getFileSizeInMB(info.getFileSizeInBytes()) + " MB\n" +
                "   Downloaded Time : " + info.getFileDownloadedTimeInSec() + " sec\n" +
                "   Average download rate : " + Utils.round(info.downloadRateKBperSec(), 3) + " KB/Sec\n" +
                "   Download at :" + Utils.formatter.format(info.getStartDownloadingTime());
    }

    public String getISPDownloadInfo(ISPDownloadInfo info) {

        return "ISP Download Info:\n" +
                "   Name : '" + info.getIsp().name() + "'\n" +
                "   Average download rate : " + Utils.round(info.getDownloadRateInKB(), 3) + " KB/Sec\n" +
                "   Download at :" + Utils.formatter.format(info.getStartMeasuringTime());
    }

    public String getSystemInfo(SystemInfo info) {

        return "System info:\n" +
                "   Operating System : " + info.getOperatingSystem() + "\n" +
                "   Browser : " + info.getBrowser() + "\n" +
                "   Public IP : " + info.getPublicIP() + "\n" +
                "   Connected via " +  info.getConnection() + " connection";
    }
}

