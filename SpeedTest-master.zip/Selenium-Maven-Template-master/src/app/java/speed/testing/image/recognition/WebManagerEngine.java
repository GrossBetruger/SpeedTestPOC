package speed.testing.image.recognition;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import speed.testing.isp.SpeedTestWebsite;
import speed.testing.test.ISPDownloadInfo;
import speed.testing.utilites.Utils;

import java.io.File;
import java.io.IOException;
import java.util.Date;
import java.util.concurrent.TimeUnit;
import java.util.logging.Logger;

import static speed.testing.image.recognition.DriverBase.getDriver;

/**
 * Created by Dan on 12/10/2016.
 */
public class WebManagerEngine implements WebManager, WebElementRecognition, CloseUIElement {

    // Logger
    private Logger log = Logger.getLogger(WebManagerEngine.class.getName());

    // Fields
    private String buttonImage;/* = "NoButton.PNG"*/;
    private WebElementRecognition webElementRecognition;
    private OcrEngine ocrEngine;

    // Constructor
    public WebManagerEngine(WebElementRecognition webElementRecognition, OcrEngine ocrEngine) {
        this.webElementRecognition = webElementRecognition;
        this.ocrEngine = ocrEngine;
    }

    // Methods

    @Override
    public ISPDownloadInfo generateISPDownloadInfo(String testID, SpeedTestWebsite SpeedTestWebsite) {

        double downloadSpeed;
        String screenshot;
        Date startMeasuringTime;
        ISPDownloadInfo ispDownloadInfo;

        try {

            openUrl(SpeedTestWebsite.webUrl());
            scrollDown();
            clickImage(SpeedTestWebsite.startTestButton());

            startMeasuringTime = new Date();
            TimeUnit.MILLISECONDS.sleep(SpeedTestWebsite.waitForTestToFinish());

            screenshot = takeScreenPic();
            closeBrowser();
            downloadSpeed = getDownloadRateSpeedFromImage(screenshot);

            if (downloadSpeed == -1) {
                return null;
            }

        } catch (Exception e) {
            log.warning("Failed to generate ISP downloadInfo for test: " + testID + "; " + e.getMessage());
            return  null;
        }

        ispDownloadInfo = new ISPDownloadInfo(SpeedTestWebsite.ISP(), downloadSpeed, startMeasuringTime);
        log.info("Speed-Test " + testID + "; DownloadSpeed : " + ispDownloadInfo.getDownloadRateInKB() + " KB");

        return ispDownloadInfo;
    }

    @Override
    public boolean clickImage(String imagePath) {
        return webElementRecognition.clickImage(imagePath);
    }

    @Override
    public String takeScreenPic() {
        return webElementRecognition.takeScreenPic();
    }

    @Override
    public boolean closeElement() {

        if (clickImage(buttonImage)) {
            log.info("Successfully closed window");
            return true;
        } else {
            log.warning("Error: Failed to close window");
            return false;
        }
    }

    private void openUrl(String url) {

        WebDriver driver;

        try {

            driver = getDriver();
            driver.get(url);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void scrollDown() throws Exception {
        JavascriptExecutor jse = (JavascriptExecutor) getDriver();
        jse.executeScript("window.scrollBy(0,250)", "");
    }

    private void closeBrowser() {
        DriverBase.clean();
    }

    // convert the image to double value,
    // @return download rate in MegaBit (Not Byte !!! )
    private double getDownloadRateSpeedFromImage(File imageFile) {

        String downloadRateStr = "";
        double downloadRateDecimalNumber = -1;

        try {

            downloadRateStr = ocrEngine.convertImageFileToString(imageFile).trim();
            downloadRateStr = downloadRateStr.replaceAll("(\\d+).+?(\\d+)", "$1\\.$2");

            log.info("Converted image file to string: " + downloadRateStr);
            downloadRateDecimalNumber = Utils.convertStrToDouble(downloadRateStr);

            if (downloadRateDecimalNumber != -1) {
                return downloadRateDecimalNumber;
            } else {
                log.warning("Failed to convert image to string");
            }

        } catch (NumberFormatException e) {
            log.warning("Failed to convert string " + downloadRateStr + " to number; " + e.getMessage());
        } catch (Exception e) {
            log.warning(e.getMessage());
        } finally {
            Utils.deleteFile(imageFile);  // Delete temp files
        }

        return downloadRateDecimalNumber;
    }

    private double getDownloadRateSpeedFromImage(String fullImagePath) throws IOException {
        File subImageFile = Utils.getSubImageFile(fullImagePath);
        return getDownloadRateSpeedFromImage(subImageFile);
    }

    public WebElementRecognition getWebElementRecognition() {
        return webElementRecognition;
    }

    public void setWebElementRecognition(WebElementRecognition webElementRecognition) {
        this.webElementRecognition = webElementRecognition;
    }

    public OcrEngine getOcrEngine() {
        return ocrEngine;
    }

    public void setOcrEngine(OcrEngine ocrEngine) {
        this.ocrEngine = ocrEngine;
    }

    public String getButtonImage() {
        return buttonImage;
    }

    public void setButtonImagePath(String buttonImage) {
        this.buttonImage = buttonImage;
    }
}
