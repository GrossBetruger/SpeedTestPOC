package speed.testing.image.recognition;

import speed.testing.Cleanable;

import java.io.File;

/**
 * Created by Dan on 08/10/2016.
 */
public interface OcrEngine extends Cleanable {
    String convertImageFileToString(File imageFile);
    void injectCloseableUiElement(CloseUIElement closeUIElement);
}
