
package speed.testing.image.recognition;// Java


import org.sikuli.script.FindFailed;
import org.sikuli.script.Screen;
import org.sikuli.script.ScreenImage;

// Assuming window is already opened by WebDriver before executing commands
public class SikuliEngine implements WebElementRecognition {

    @Override
    public boolean clickImage(String imagePath) {

        try {
            Screen screen = new Screen();
            screen.exists(imagePath);
            screen.click(imagePath);

        } catch (FindFailed ff) {
            return false;
        }

        return true;
    }

    @Override
    public String takeScreenPic() {

        try {
            Screen screen = new Screen();
            ScreenImage image = screen.capture();

            return image.getFile();
        } catch (Exception e) {
            return null;
        }
    }
}
