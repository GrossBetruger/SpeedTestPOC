package speed.testing.image.recognition;

/**
 * Created by Dan on 15/10/2016.
 */
public interface CloseUIElement {
    boolean closeElement();
}
