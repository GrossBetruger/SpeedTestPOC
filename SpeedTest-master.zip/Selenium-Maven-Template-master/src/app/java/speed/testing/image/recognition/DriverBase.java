package speed.testing.image.recognition;

import speed.testing.image.recognition.config.DriverFactory;
import org.openqa.selenium.WebDriver;
import speed.testing.image.recognition.config.DriverType;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.*;
import java.util.*;
import java.util.logging.Logger;
import java.util.stream.Collectors;

public class DriverBase {

    // Logger
    private static Logger log = Logger.getLogger(DriverBase.class.getName());

    private static DriverFactory driverFactory;

    static {
        instantiateDriverObject();
    }

    public static void instantiateDriverObject() {
        driverFactory = new DriverFactory();
    }

    public static WebDriver getDriver() throws Exception {
        return driverFactory.getDriver();
    }

    public static void clean() {

        try {
            clearCookies();
            closeDriverObjects();

        } catch (Exception e) {
            System.out.println("Failed to clean driver base");
        }
    }

    private static void clearCookies() throws Exception {
        getDriver().manage().deleteAllCookies();
    }

    private static void closeDriverObjects() {
        driverFactory.quitDriver();
    }

    public static String getOperatingSystem() {
        return driverFactory.getOperatingSystem();
    }

    public static DriverType getSelectedDriverType() {
        return driverFactory.getSelectedDriverType();
    }

    public static String getPublicIPAddress() {

        try {

            URL amazonawsCheckIP = new URL("http://checkip.amazonaws.com");
            BufferedReader in = new BufferedReader(new InputStreamReader(amazonawsCheckIP.openStream()));
            String ip = in.readLine(); // Get the IP as a String

            return ip;

        } catch (IOException e) {
            log.warning("Failed to retrieve public IP address " + e.getMessage());
            return "Unknown public IP";
        }
    }

    public static String getConnection() {

        Boolean isUp;
        Boolean isHardwareAddress;
        boolean foundConnectionDriver = false;
        Enumeration<NetworkInterface> interfaces = getNetworkInterface();

        if (interfaces == null) {
            return "Unknown";
        }

        for (NetworkInterface networkInterface : Collections.list(interfaces)) {

            isUp = isUp(networkInterface);
            isHardwareAddress = isHardwareAddress(networkInterface);

            if (networkIsUpAndRunning(isUp) && isHardwareAddressAccessible(isHardwareAddress)) {

                foundConnectionDriver = true;

                if (isEthernetConnection(networkInterface)) {
                    return "LAN";
                }
            }
        }

        return foundConnectionDriver ? "Wifi" : "Unknown";
    }

    private static boolean isHardwareAddressAccessible(Boolean isHardwareAddress) {
        return isHardwareAddress != null && isHardwareAddress;
    }

    private static boolean networkIsUpAndRunning(Boolean isUp) {
        return isUp != null && isUp;
    }

    private static Enumeration<NetworkInterface> getNetworkInterface() {
        Enumeration<NetworkInterface> interfaces;

        try {
            interfaces = NetworkInterface.getNetworkInterfaces();

        } catch (SocketException e) {
            log.warning(e.getMessage());
            return null;
        }

        return interfaces;
    }

    // Returns whether a network interface is up and running.
    private static Boolean isUp(NetworkInterface networkInterface) {

        try {
            return networkInterface.isUp();

        } catch (SocketException e) {
            log.warning(e.getMessage());
            return null;
        }
    }

    // Returns the hardware address (usually MAC)
    private static Boolean isHardwareAddress(NetworkInterface networkInterface) {

        try {
            return networkInterface.getHardwareAddress() != null;

        } catch (SocketException e) {
            log.warning(e.getMessage());
            return null;
        }
    }

    private static boolean isEthernetConnection(NetworkInterface networkInterface) {

        return networkInterface != null &&
               networkInterface.getName() != null &&
               networkInterface.getName().contains("eth");
    }
}